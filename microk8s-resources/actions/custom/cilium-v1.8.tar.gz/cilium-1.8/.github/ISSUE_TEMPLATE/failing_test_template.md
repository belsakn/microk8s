---
name: Failing Test
about: Report test failures in Cilium CI jobs
title: 'CI: '
labels: area/CI
assignees: ''

---

## CI failure

- Set title to be in the format `CI: <test-name>`
- Copy-paste the output the test failure
- Upload the zip file generated from that test failure
- Copy-paste the link of the CI build where that test failure has happen
