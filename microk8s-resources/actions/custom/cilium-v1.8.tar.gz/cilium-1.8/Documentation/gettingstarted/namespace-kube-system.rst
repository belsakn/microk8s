Specify Environment Variables
=============================

Specify the namespace in which Cilium is installed as ``CILIUM_NAMESPACE``
environment variable. Subsequent commands reference this environment variable.

.. parsed-literal::

   export CILIUM_NAMESPACE=kube-system
