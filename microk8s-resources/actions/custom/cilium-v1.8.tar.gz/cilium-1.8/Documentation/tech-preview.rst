.. note:: This feature is currently only in technology preview and to be used
          for experimentation purposes. This restriction will be lifted in
          future Cilium releases.
