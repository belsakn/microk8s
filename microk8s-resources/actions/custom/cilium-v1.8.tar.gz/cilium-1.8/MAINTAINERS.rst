Maintainers
===========

 * `André Martins`_ (Isovalent)
 * `Joe Stringer`_ (Isovalent)

Core Team
=========

 * `Daniel Borkmann`_ (Isovalent)
 * `Deepesh Pathak`_
 * `Eloy Coto`_ (Red Hat)
 * `Ian Vernon`_
 * `Jarno Rajahalme`_ (Isovalent)
 * `John Fastabend`_ (Isovalent)
 * `Laurent Bernaille`_ (Datadog)
 * `Maciej Kwiek`_ (Isovalent)
 * `Martynas Pumputis`_ (Isovalent)
 * `Michael Rostecki`_ (SUSE)
 * `Nirmoy Das`_ (AMD)
 * `Ray Bejjani`_ (Isovalent)
 * `Thomas Graf`_ (Isovalent)
 * `Vlad Ungureanu`_ (Palantir)

Please see the AUTHORS file for the full list of contributors to the Cilium
project.

.. _`André Martins`: https://github.com/aanm
.. _`Joe Stringer`: https://github.com/joestringer
.. _`Daniel Borkmann`: https://github.com/borkmann
.. _`Deepesh Pathak`: https://github.com/fristonio
.. _`Eloy Coto`: https://github.com/eloycoto
.. _`Ian Vernon`: https://github.com/ianvernon
.. _`Jarno Rajahalme`: https://github.com/jrajahalme
.. _`John Fastabend`: https://github.com/jrfastab
.. _`Laurent Bernaille`: https://github.com/lbernail
.. _`Maciej Kwiek`: https://github.com/nebril
.. _`Martynas Pumputis`: https://github.com/brb
.. _`Michael Rostecki`: https://github.com/mrostecki
.. _`Nirmoy Das`: https://github.com/nirmoy
.. _`Ray Bejjani`: https://github.com/raybejjani
.. _`Thomas Graf`: https://github.com/tgraf
.. _`Vlad Ungureanu`: https://github.com/ungureanuvladvictor
